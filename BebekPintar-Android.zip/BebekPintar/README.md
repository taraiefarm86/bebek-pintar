# Bebek Pintar (Android)
Aplikasi WebView yang membungkus app/src/main/assets/index.html.

## Cara 1 - Android Studio
Buka folder ini, tunggu sync, lalu Build > Build APK(s).
Hasil: app/build/outputs/apk/debug/app-debug.apk

## Cara 2 - Tanpa Android Studio (GitHub)
1. Buat repo GitHub, upload seluruh isi folder ini (termasuk folder .github).
2. Buka tab Actions > "Build APK" > tunggu selesai.
3. Unduh artifact "BebekPintar-apk", ekstrak, lalu pasang app-debug.apk di HP
   (izinkan "Install dari sumber tidak dikenal").
